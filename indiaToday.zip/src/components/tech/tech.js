import React from 'react'



const Tech = ()=>{
    return(<div>

<h2>dfadff</h2>
    </div>)
}

export default Tech