import React from 'react'



const Tech = ()=>{
    return(<div>

<h2>Temp</h2>
    </div>)
}

export default Tech