
// CSS FIle
import '../assets/css/style.css'

// Components
import Header from './Header'
import Body from './Body'
import Footer from './Footer'



function LandingPage() {
    return (

        <Body />

    );
}

export default LandingPage;
