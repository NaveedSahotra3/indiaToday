import React from 'react'
import imgss from '../assets/indiatoday/styles/user_picture/public/images/reporter/202009/sEOiKTvO_400x400-1200x76863e6.jpg'

const NewStory = ()=>{
    return(<>

<body class="html not-front not-logged-in one-sidebar sidebar-second page-node page-node- page-node-1783659 node-type-story section-india">
	<p id="skip-link"><a class="element-invisible element-focusable" href="#main-menu">Jump to navigation</a></p>




	<div id="target-1"></div>
	<div id='div-gpt-ad-1585722889288-0' style={{width: '1px', height: '1px'}}>
	
	</div>
	<div id='div-gpt-ad-1607494382215-0' style={{width: '1px', height: '1px'}}>
	
	</div>


	<div id="page">
	
		<main class="container pos-rel" id="main">
			<div class="row">
				<section class="col-md-8" id="content" role="main">
					<a id="main-content"></a>
					<div class="front-end-breadcrumb"></div>
				 <input class="get_story_node" name="get_story_node" type="hidden" value="1783659"/>
					<div class="story-section">
						<article itemscope itemtype="http://schema.org/NewsArticle">
							<link href="crew-of-ever-green-ship-blocking-suez-canal-is-indian-1783659-2021-03-25.html" itemprop="mainEntityOfPage"/>
							<div itemprop="publisher" itemscope itemtype="https://schema.org/Organization">
								<div content="https://www.indiatoday.in/sites/all/themes/itg/logo.png" itemprop="logo" itemscope itemtype="https://schema.org/ImageObject">
									<meta content="https://www.indiatoday.in/sites/all/themes/itg/logo.png" itemprop="url"/>
									<meta content="600" itemprop="width"/>
									<meta content="60" itemprop="height"/>
								</div>
								<meta content="India Today" itemprop="name"/>
								<link href="../../index.html" itemprop="sameAs"/>
							</div>
							<div class='node node-story view-mode-full'>
								<h1 itemprop="headline">Entire crew of Ever Green, container ship blocking Suez Canal, is Indian; all are safe</h1>
								<div class="story-left-section story-update">
									<div class="story-kicker">
										<h2>Bernhard Schulte Shipmanagement, the company that manages the Ever Given, said the ship's 25-member crew are safe and accounted for.</h2>
									</div>
									<div class="story-header-wrapper">
										<div class="story-header-ad">
											<div class='adtext'>
												advertisement
											</div>
											<div id='indiatoday_story_tablet_con'></div>
										
										
										</div>
										<div class="story-left">
											<div class="byline">
												<div class="profile-pic">
													<a href="../../author/indiatoday-in.html" target="_blank" title="India Today Web Desk"><img alt=""
                                                     src={imgss} title=""/></a>
												</div>
												<div class="profile-detail">
													<meta content="India" itemprop="articleSection"/>
													<meta content="https://www.indiatoday.in/india/story/crew-of-ever-green-ship-blocking-suez-canal-is-indian-1783659-2021-03-25" itemprop="url"/>
													<meta content="Bernhard Schulte Shipmanagement, the company that manages the Ever Given, said the ship's 25-member crew are safe and accounted for." itemprop="description"/>
													<meta content="" itemprop="keywords"/>
													<meta content="2021-03-25T19:29:04+05:30" itemprop="datePublished"/>
													<meta content="2021-03-25T19:29:04+05:30" property="article:published_time"/>
													<meta content="2021-03-25T19:39:31+05:30" itemprop="dateModified"/>
													<meta content="2021-03-25T19:39:31+05:30" property="article:modified_time"/>
													<dl class="profile-byline">
														<dd><span itemprop="author" itemscope itemtype="https://schema.org/Person"></span></dd>
														<dt class="title" itemprop="name"><span itemprop="author" itemscope itemtype="https://schema.org/Person"><a href="../../author/indiatoday-in.html" target="_blank" title="India Today Web Desk">India Today Web Desk</a> <span class="mobile-twitter"><a href="https://twitter.com/intent/follow?screen_name=IndiaToday" title="India Today Web Desk"><i class="fa fa-twitter"></i></a></span></span></dt>
														<dt>New Delhi</dt>
														<dt class="pubdata">March 25, 2021</dt>
														<dt class="update-data"><span class="update-data">UPDATED: March 25, 2021 19:39 IST</span></dt>
													</dl>
												</div>
											</div>
											<div class="share_bar" id="share_bar">
												<dl class="list-inline social-share">
													<dt>
														<a class="def-cur-pointer yticon" href="https://www.youtube.com/channel/UCYPvAwZP8pZhSMW8qs7cVCw?sub_confirmation=1" target="_blank" title="YT Subscription"><svg style={{enableBackground:"new 0 0 30 30"}} version="1.1" viewbox="0 0 30 30" x="0px" xmlns="http://www.w3.org/2000/svg" y="0px">
														<g>
															<circle cx="15" cy="15" fill="#ee2324" r="15"></circle>
															<path d="M24,13c0-0.2,0-0.4,0-0.6c-0.1-0.9-0.2-1.9-0.8-2.7c-0.5-0.6-1.3-0.8-2.1-0.8c-0.9-0.1-1.9-0.2-2.9-0.2c-1.9-0.1-3.9,0-5.8,0c-1,0-2,0-3,0.1c-1.2,0.1-2.5,0.3-3,1.5C5.9,11.4,6,12.8,6,13.9c0,1.1,0,2.1,0,3.2c0.1,1.4,0.1,3.1,1.6,3.7c0.8,0.3,1.7,0.4,2.6,0.4c0.9,0.1,1.8,0.1,2.7,0.1c1.9,0,3.7,0,5.6-0.1c1.3,0,2.6,0,3.9-0.5c1.1-0.4,1.4-1.5,1.5-2.5c0.1-1,0.1-2,0.1-3C24,14.5,24,13.8,24,13z M13.2,17.7c0-1.8,0-3.6,0-5.5c1.6,0.9,3.1,1.8,4.7,2.7C16.3,15.9,14.7,16.8,13.2,17.7z" fill="#FFFFFF"></path>
														</g></svg></a>
													</dt>
													<dt>
														<a class="def-cur-pointer fbicon" onclick="fbpop('crew-of-ever-green-ship-blocking-suez-canal-is-indian-1783659-2021-03-25f86b.html?utm_source=fbshare&amp;utm_medium=socialicons&amp;utm_campaign=shareurltracking', 'Entire crew of Ever Green, container ship blocking Suez Canal, is Indian; all are safe', '', '../../../akm-img-a-in.tosshub.com/indiatoday/images/story/202103/000_96M344-647x36366f7.jpg?R9afjgR1iGQQynOlH7bVg.C2gV6lJWw9', '../../index.html', '1783659'); ga('send', 'event', { eventCategory: 'facebookStory', eventAction: 'click', eventLabel: 'sharebutton'})" rel="noopener noreferrer" title="share on facebook"><svg height="30" style={{enableBackground:"new 0 0 30 30"}} version="1.1" viewbox="0 0 30 30" width="30" x="0px" xmlns="http://www.w3.org/2000/svg" y="0px">
														<g>
															<circle cx="15" cy="15" fill="#3b549a" r="15"></circle>
															<path d="M16.3,23.5v-7.8h2.6l0.4-3h-3v-1.9c0-0.9,0.2-1.5,1.5-1.5l1.6,0V6.6c-0.3,0-1.2-0.1-2.3-0.1c-2.3,0-3.9,1.4-3.9,4v2.2h-2.6v3h2.6v7.8H16.3L16.3,23.5z" fill="#FFFFFF"></path>
														</g></svg></a>
													</dt>
													<dt>
														<a class="user-activity twicon" data-activity="twitter_share" data-rel="1783659" data-status="1" data-tag="story" href="javascript:void(0)" onclick="twitter_popup('Entire+crew+of+Ever+Green%2C+container+ship+blocking+Suez+Canal%2C+is+Indian%3B+all+are+safe', 'https%3A%2F%2Fwww.indiatoday.in%2Findia%2Fstory%2Fcrew-of-ever-green-ship-blocking-suez-canal-is-indian-1783659-2021-03-25%3Futm_source%3Dtwshare%26utm_medium%3Dsocialicons%26utm_campaign%3Dshareurltracking');ga('send', 'event', { eventCategory: 'twitterStory', eventAction: 'click', eventLabel: 'sharebutton'})" rel="noopener noreferrer" title="share on twitter"><svg height="30" style={{enableBackground:"new 0 0 30 30"}} version="1.1" viewbox="0 0 30 30" width="30" x="0px" xmlns="http://www.w3.org/2000/svg" y="0px">
														<g>
															<circle cx="15" cy="15" fill="#82c3eb" r="15"></circle>
															<g>
																<path d="M24.4,10.3c-0.4,0.1-0.8,0.1-0.8,0.1l0-0.1c0.4-0.3,1.4-1.3,1.5-1.8c0.1-0.2,0-0.3,0-0.3l-1.3,0.5l-1.1,0.5l0,0C22.1,8.5,21,8,19.7,8c-2.2,0-4,1.6-4,3.5c0,0.4,0.1,1,0.2,1.3c0,0.1,0-0.1,0,0c-1.4,0-3.3-0.6-4.9-1.5C7.7,9.8,7.5,8.6,7.5,8.6C7,9.2,6.7,11,7.2,12.4c0.3,0.9,1.5,1.7,1.5,1.7l0,0c0,0-0.5,0-1-0.2c-0.5-0.2-0.7-0.4-0.7-0.4c-0.3,0.8,0.3,2.1,1.4,3.1c0.6,0.6,1.8,0.9,1.8,0.9l-1.8,0.1c-0.1,1.8,3.7,2.8,3.7,2.8l0,0c-1.1,0.9-2.4,1.4-3.8,1.4c-0.7,0-1.4-0.1-2.1-0.3c1.8,1.5,4.2,2.6,6.8,2.4c6.8-0.4,10.7-6.2,10.8-12l0,0c0,0,0.3-0.2,1-0.8c0.7-0.7,1.1-1.5,1.1-1.5S24.8,10.1,24.4,10.3z" fill="#FFFFFF"></path>
															</g>
														</g></svg></a>
													</dt>
													<dt class="mhide">
														<a class="whatsapp_share whticon" data-href="crew-of-ever-green-ship-blocking-suez-canal-is-indian-1783659-2021-03-25b891.html?utm_source=washare&amp;utm_medium=socialicons&amp;utm_campaign=shareurltracking" data-text="Entire crew of Ever Green, container ship blocking Suez Canal, is Indian; all are safe" href="https://web.whatsapp.com:/send?text=Entire%20crew%20of%20Ever%20Green%2C%20container%20ship%20blocking%20Suez%20Canal%2C%20is%20Indian%3B%20all%20are%20safe%20https%3A%2F%2Fwww.indiatoday.in%2Findia%2Fstory%2Fcrew-of-ever-green-ship-blocking-suez-canal-is-indian-1783659-2021-03-25%3Futm_source%3Dwashare%26utm_medium%3Dsocialicons%26utm_campaign%3Dshareurltracking%20%0A%0ADownload%20the%20India%20Today%20app%20now%20to%20read%20our%20latest%20stories.%0Ahttps%3A%2F%2Findiatoday.app.link%2FTrK1ggqhLT" onclick="ga('send', 'event', { eventCategory: 'whatsappStory', eventAction: 'click', eventLabel: 'sharebutton'});" rel="noopener noreferrer" target="_blank" title="share on whatsapp"><svg style={{enableBackground:"new 0 0 30 30"}} version="1.1" viewbox="0 0 30 30" x="0px" xmlns="http://www.w3.org/2000/svg" y="0px">
														<g>
															<g>
																<circle cx="15" cy="15" fill="#3eb64a" r="15"></circle>
															</g>
															<g>
																<g>
																	<path d="M15,23.5c-1.5,0-2.9-0.4-4.2-1.1l-3.3,1.1L8.1,20c-1.1-1.5-1.6-3.2-1.6-5c0-4.7,3.8-8.5,8.5-8.5c4.7,0,8.5,3.8,8.5,8.5C23.5,19.7,19.7,23.5,15,23.5z M10.9,21l0.3,0.2c1.2,0.7,2.5,1.1,3.8,1.1c4,0,7.2-3.2,7.2-7.2c0-4-3.2-7.2-7.2-7.2c-4,0-7.2,3.2-7.2,7.2c0,1.6,0.5,3.2,1.5,4.4l0.2,0.2l-0.4,1.9L10.9,21z" fill="#FFFFFF"></path>
																</g>
																<path class="st1" d="M10.7,11.7c0,0,0.5-0.9,0.9-0.9c0.4,0,0.9,0,1.1,0.2c0.1,0.3,0.8,1.8,0.8,1.8s0.1,0.3-0.1,0.5c-0.2,0.3-0.5,0.6-0.5,0.6s-0.2,0.3,0,0.5c0.2,0.3,0.5,0.8,1.2,1.5c0.7,0.7,1.9,1.1,1.9,1.1s0.2,0,0.3-0.1c0.1-0.1,0.7-0.9,0.7-0.9s0.2-0.3,0.5-0.1c0.3,0.2,1.8,0.9,1.8,0.9s0.2,0.1,0.2,0.3c0,0.3-0.1,0.9-0.3,1.1c-0.2,0.2-0.8,0.9-1.8,0.9c-0.9,0-3.2-0.8-4.4-1.9c-1.2-1.2-2.2-2.4-2.5-3.5C10.4,12.7,10.4,12.2,10.7,11.7z"></path>
															</g>
														</g></svg></a>
													</dt>
													<dt class="desktop-hide">
														<a class="whatsapp_share whticonm" data-href="crew-of-ever-green-ship-blocking-suez-canal-is-indian-1783659-2021-03-25b891.html?utm_source=washare&amp;utm_medium=socialicons&amp;utm_campaign=shareurltracking" data-text="Entire crew of Ever Green, container ship blocking Suez Canal, is Indian; all are safe" href="whatsapp://send?text=Entire%20crew%20of%20Ever%20Green%2C%20container%20ship%20blocking%20Suez%20Canal%2C%20is%20Indian%3B%20all%20are%20safe%20https%3A%2F%2Fwww.indiatoday.in%2Findia%2Fstory%2Fcrew-of-ever-green-ship-blocking-suez-canal-is-indian-1783659-2021-03-25%3Futm_source%3Dwashare%26utm_medium%3Dsocialicons%26utm_campaign%3Dshareurltracking%20%0A%0ADownload%20the%20India%20Today%20app%20now%20to%20read%20our%20latest%20stories.%0Ahttps%3A%2F%2Findiatoday.app.link%2FTrK1ggqhLT" onclick="ga('send', 'event', { eventCategory: 'whatsappStory', eventAction: 'click', eventLabel: 'sharebutton'});" rel="noopener noreferrer" title="share on whatsapp"><svg style={{enableBackground:"new 0 0 30 30"}} version="1.1" viewbox="0 0 30 30" x="0px" xmlns="http://www.w3.org/2000/svg" y="0px">
														<g>
															<g>
																<circle cx="15" cy="15" fill="#368a41" r="15"></circle>
															</g>
															<g>
																<g>
																	<path d="M15,23.5c-1.5,0-2.9-0.4-4.2-1.1l-3.3,1.1L8.1,20c-1.1-1.5-1.6-3.2-1.6-5c0-4.7,3.8-8.5,8.5-8.5c4.7,0,8.5,3.8,8.5,8.5C23.5,19.7,19.7,23.5,15,23.5z M10.9,21l0.3,0.2c1.2,0.7,2.5,1.1,3.8,1.1c4,0,7.2-3.2,7.2-7.2c0-4-3.2-7.2-7.2-7.2c-4,0-7.2,3.2-7.2,7.2c0,1.6,0.5,3.2,1.5,4.4l0.2,0.2l-0.4,1.9L10.9,21z" fill="#FFFFFF"></path>
																</g>
																<path class="st1" d="M10.7,11.7c0,0,0.5-0.9,0.9-0.9c0.4,0,0.9,0,1.1,0.2c0.1,0.3,0.8,1.8,0.8,1.8s0.1,0.3-0.1,0.5c-0.2,0.3-0.5,0.6-0.5,0.6s-0.2,0.3,0,0.5c0.2,0.3,0.5,0.8,1.2,1.5c0.7,0.7,1.9,1.1,1.9,1.1s0.2,0,0.3-0.1c0.1-0.1,0.7-0.9,0.7-0.9s0.2-0.3,0.5-0.1c0.3,0.2,1.8,0.9,1.8,0.9s0.2,0.1,0.2,0.3c0,0.3-0.1,0.9-0.3,1.1c-0.2,0.2-0.8,0.9-1.8,0.9c-0.9,0-3.2-0.8-4.4-1.9c-1.2-1.2-2.2-2.4-2.5-3.5C10.4,12.7,10.4,12.2,10.7,11.7z"></path>
															</g>
														</g></svg></a>
													</dt>
													<dt class="itg-activity-read-later user-activity-trigger">
														<a class="user-activity def-cur-pointer bookmrkicon" data-activity="read_later" data-rel="1783659" data-status="1" data-tag="story" href="javascript:void(0)" onclick="ga('send', 'event', { eventCategory: 'readStory', eventAction: 'click', eventLabel: 'sharebutton'});" title="Bookmark"><svg height="30" style={{enableBackground:"new 0 0 30 30"}} version="1.1" viewbox="0 0 30 30" width="30" x="0px" xmlns="http://www.w3.org/2000/svg" y="0px">
													
														<g>
															<g>
																<circle cx="15" cy="15" fill="#F69220" r="15"></circle>
															</g>
															<g>
																<path class="st1" d="M19.8,6.5c0.1,0,0.3,0,0.4,0.1c0.4,0.2,0.7,0.5,0.7,0.9v15c0,0.4-0.3,0.8-0.7,0.9c-0.1,0.1-0.3,0.1-0.4,0.1c-0.3,0-0.5-0.1-0.8-0.3l-4-3.9l-4,3.9c-0.2,0.2-0.5,0.3-0.8,0.3c-0.1,0-0.3,0-0.4-0.1c-0.4-0.2-0.7-0.5-0.7-0.9v-15c0-0.4,0.3-0.8,0.7-0.9c0.1-0.1,0.3-0.1,0.4-0.1H19.8L19.8,6.5z"></path>
															</g>
														</g></svg></a>
													</dt>
													<dt>
														<a class="comnticon def-cur-pointer postCommentBut1783659" onclick="ga('send', 'event', { eventCategory: 'commentStory', eventAction: 'click', eventLabel: 'sharebutton'});" title="comment"><svg style={{enableBackground:"new 0 0 30 30"}} version="1.1" viewbox="0 0 30 30" x="0px" xmlns="http://www.w3.org/2000/svg" y="0px">
													
														<g>
															<g>
																<circle cx="15" cy="15" fill="#dab227" r="15"></circle>
															</g>
															<g>
																<g transform="translate(-238.000000, -842.000000)">
																	<g transform="translate(238.000000, 842.000000)">
																		<path class="st1" d="M7.5,18.2l0.1,0.1c0,0,0,0.2-0.1,0.3c-0.1,0.3-0.2,0.5-0.5,1.2c-0.3,0.7-0.4,1-0.5,1.3c-0.2,0.6-0.3,1,0.1,1.3c0.3,0.2,0.6,0.2,1.4,0c0.4-0.1,2.8-1,3.2-1.1c0.2-0.1,0.4-0.1,0.5-0.1c0.1,0,0.1,0,0.1,0c0,0,0,0,0,0c1,0.3,2.1,0.5,3.2,0.5c4.8,0,8.8-3.1,8.8-7s-4-7-8.8-7s-8.8,3.1-8.8,7c0,0.9,0.2,1.9,0.7,2.7C7.1,17.6,7.3,17.9,7.5,18.2z"></path>
																	</g>
																</g>
															</g>
														</g></svg></a>
													</dt>
												</dl>
											</div>
										</div>
									</div>
									<div class="story-right">
										<div class="" itemprop="associatedMedia image" itemscope itemtype="https://schema.org/ImageObject">
											<meta content="true" itemprop="representativeOfPage"/>
											<div class="stryimg">
												<img alt="suez canal latest news" class="lazyload" data-src="https://akm-img-a-in.tosshub.com/indiatoday/images/story/202103/000_96M344_1200x768.jpeg?pBTCffui2qP4_XmeVEqLnvtE_SHR.zW3&amp;size=770:433" height="433" src="../../../akm-img-a-in.tosshub.com/" title="suez canal latest news" width="770"/>
												<meta content="https://akm-img-a-in.tosshub.com/indiatoday/images/story/202103/000_96M344_1200x768.jpeg?pBTCffui2qP4_XmeVEqLnvtE_SHR.zW3&size=1200:675" itemprop="contentUrl"/>
												<meta content="https://akm-img-a-in.tosshub.com/indiatoday/images/story/202103/000_96M344_1200x768.jpeg?pBTCffui2qP4_XmeVEqLnvtE_SHR.zW3&size=1200:675" itemprop="url"/>
												<meta content="1200" itemprop="width"/>
												<meta content="675" itemprop="height"/>
												<div class="photoby"></div>
											</div>
											<div class="image-alt" itemprop="description">
												The ship is stuck in the Suez Canal since Tuesday, blocking traffic in one of the world's busiest waterways. (Photo: AFP)
											</div>
										</div>
										<div class="story-movie">
											<div class="movie-detail"></div>
										</div>
										<div class="description" itemprop="articleBody">
											<p>The crew of Ever Green, the container ship that is stuck in the Suez Canal since Tuesday blocking traffic in one of the world's busiest waterways, is Indian and all members are safe, said the company managing the container.</p>
											<p>In a report, news agency The Associated Press said Bernhard Schulte Shipmanagement, the company that manages the Ever Given, said the ship's 25-member crew are safe and accounted for.</p>
											<p>Shoei Kisen Kaisha, the company's owner, said, "All the crew came from India."</p>
											<p>Apart from the Indian crew, the ship had two pilots from Egypt's canal authority aboard the vessel to guide it when the grounding happened around 7:45 am on Tuesday.</p>
											<p></p>
										</div><iframe allowfullscreen="true" class=" lazyload newsltter-iframe" data-src="https://www.indiatodaygroup.com/newsletter-subscription/widgets/display_form.php?key=ad6359e0dd5646903042ff9da553882c" frameborder="0" scrolling="no" style={{border: '0px',verticalAlign: 'bottom',width: '100%' ,left: '0px',top: '0px' }}></iframe>
									
									</div>
								</div>
							</div>
						</article>
						<div class="clearfix"></div>
						<div class="comment-vuukle-count"></div>
						<div class="clearfix"></div>
						<div class="section-left-bototm">
							<div class="social-list">
								<dl>
									<dt class="mhide"></dt>
									<dd>
										<div id="fb-root"></div><a class="def-cur-pointer" onclick="fbpop('crew-of-ever-green-ship-blocking-suez-canal-is-indian-1783659-2021-03-25f86b.html?utm_source=fbshare&amp;utm_medium=socialicons&amp;utm_campaign=shareurltracking', 'Entire crew of Ever Green, container ship blocking Suez Canal, is Indian; all are safe', '', '../../../akm-img-a-in.tosshub.com/indiatoday/images/story/202103/000_96M344-647x36366f7.jpg?R9afjgR1iGQQynOlH7bVg.C2gV6lJWw9', '../../index.html', '1783659')" rel="noopener noreferrer" title="share on facebook"><i class="fa fa-facebook"></i></a>
									</dd>
									<dt class="mhide">
										<a class="user-activity" data-activity="twitter_share" data-rel="1783659" data-status="1" data-tag="story" href="javascript:" onclick="twitter_popup('Entire+crew+of+Ever+Green%2C+container+ship+blocking+Suez+Canal%2C+is+Indian%3B+all+are+safe', 'https%3A%2F%2Fwww.indiatoday.in%2Findia%2Fstory%2Fcrew-of-ever-green-ship-blocking-suez-canal-is-indian-1783659-2021-03-25%3Futm_source%3Dtwshare%26utm_medium%3Dsocialicons%26utm_campaign%3Dshareurltracking')" rel="noopener noreferrer" title="share on twitter"><i class="fa fa-twitter"></i></a>
									</dt>
									<dt class="mhide">
										<a class="def-cur-pointer postCommentBut1783659" title="comment"><i class="fa fa-comment"></i> <span></span></a>
									</dt>
									<dt class="mhide"><span class="posted-by">Posted by</span><span class="posted-name">Mukesh Rawat</span></dt>
								</dl>
							</div>
						</div>
						<div class="vukkul-comment">
							<div class="inhouse-comment-view">
								<div class="itgdcommentMod" id="itgdcommentMod1783659"></div>
					
							</div>
						
							
						</div>
					
					
					</div>
				</section>
				<aside class="sidebars col-md-4">
					<section class="region region-sidebar-second column sidebar">
						<div class="block block-itg-ads first odd" id="block-itg-ads-ads-medium-rectangl-rhs1-300x250">
							<div class='adtext'>
								advertisement
							</div>
							<div id='div-gpt-ad-1507709583969-1' style={{height:'250px', width:'300px'}}>
							
							</div>
						
						</div>
						<div class="block block-itg-widget even" id="block-itg-widget-we-may-suggest">
							<div class="may-be-suggest-container">
								<h3><span>READ THIS</span></h3>
								<ul>
									<li class="may-we-suggest">
										<a class="pic" href="union-ministers-bjp-leaders-social-media-condemn-tweets-farmers-protest-rihanna-greta-1765518-2021-02-035be9.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=readthis&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=readthis" title="Top BJP leaders take to social media to condemn tweets on farmers' stir by Rihanna, Greta"><img alt="BJP chief JP Nadda " class="lazyload" data-src="https://akm-img-a-in.tosshub.com/indiatoday/images/story/202102/Nadda_1200x768.jpeg?size=88:50" height="50" src="../../../akm-img-a-in.tosshub.com/sites/all/themes/itg/images/itg_image88x50.jpg" title="BJP chief JP Nadda " width="88"/></a>
										<p class="title may-be-suggest-1765518" title="Top BJP leaders take to social media to condemn tweets on farmers' stir by Rihanna, Greta"><a href="union-ministers-bjp-leaders-social-media-condemn-tweets-farmers-protest-rihanna-greta-1765518-2021-02-035be9.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=readthis&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=readthis" title="Top BJP leaders take to social media to condemn tweets on farmers stir by Rihanna, Greta">Top BJP leaders take to social media to condemn tweets on farmers' stir by Rihanna, Greta</a></p>
									</li>
									<li class="may-we-suggest">
										<a class="pic" href="../../news-analysis/story/the-efficacy-of-double-masking-what-health-experts-have-to-say-1765551-2021-02-035be9.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=readthis&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=readthis" title="The efficacy of double masking: What health experts have to say "><img alt="" class="lazyload" data-src="https://akm-img-a-in.tosshub.com/indiatoday/images/story/202102/PTI_corona_PPE_1200x768.png?size=88:50" height="50" src="../../../akm-img-a-in.tosshub.com/sites/all/themes/itg/images/itg_image88x50.jpg" title="" width="88"/></a>
										<p class="title may-be-suggest-1765551" title="The efficacy of double masking: What health experts have to say "><a href="../../news-analysis/story/the-efficacy-of-double-masking-what-health-experts-have-to-say-1765551-2021-02-035be9.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=readthis&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=readthis" title="The efficacy of double masking: What health experts have to say ">The efficacy of double masking: What health experts have to say</a></p>
									</li>
									<li class="may-we-suggest">
										<a class="pic" href="../../magazine/nation/story/20210208-silenced-minority-1763812-2021-01-305be9.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=readthis&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=readthis" title="Silenced Minority?"><img alt="" class="lazyload" data-src="https://akm-img-a-in.tosshub.com/indiatoday/images/story/202101/Republic-Minorities-Feb8-1_1200x768.jpeg?size=88:50" height="50" src="../../../akm-img-a-in.tosshub.com/sites/all/themes/itg/images/itg_image88x50.jpg" title="" width="88"/></a>
										<p class="title may-be-suggest-1763812" title="Silenced Minority?"><a href="../../magazine/nation/story/20210208-silenced-minority-1763812-2021-01-305be9.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=readthis&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=readthis" title="Silenced Minority?">Silenced Minority?</a></p>
									</li>
									<li class="may-we-suggest">
										<a class="pic" href="../../technology/news/story/airtel-jio-vi-best-prepaid-plans-with-streaming-and-data-benefits-under-rs-500-1765585-2021-02-035be9.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=readthis&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=readthis" title="Airtel, Jio, Vi best prepaid plans with streaming and data benefits under Rs 500"><img alt="" class="lazyload" data-src="https://akm-img-a-in.tosshub.com/indiatoday/images/story/202102/IMG_20210203_174806_1200x768.jpeg?size=88:50" height="50" src="../../../akm-img-a-in.tosshub.com/sites/all/themes/itg/images/itg_image88x50.jpg" title="" width="88"/></a>
										<p class="title may-be-suggest-1765585" title="Airtel, Jio, Vi best prepaid plans with streaming and data benefits under Rs 500"><a href="../../technology/news/story/airtel-jio-vi-best-prepaid-plans-with-streaming-and-data-benefits-under-rs-500-1765585-2021-02-035be9.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=readthis&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=readthis" title="Airtel, Jio, Vi best prepaid plans with streaming and data benefits under Rs 500">Airtel, Jio, Vi best prepaid plans with streaming and data benefits under Rs 500</a></p>
									</li>
								</ul>
							</div>
						</div>
						<div class="block block-itg-front-end-common odd" id="block-itg-front-end-common-recommend-news-block">
							<div class="may-be-recommend mhide">
								<h3><span>Recommended</span></h3>
								<div id="taboola-right-rail-thumbnails"></div>
							
							</div>
						</div>
						<div class="block block-itg-widget even" id="block-itg-widget-watch-right-now-videos-widget">
							<div class="watch-right-now-video">
								<h3><span>Watch Right Now</span></h3>
								<ul>
									<li class="watch-right-now-list watch-right-now-0">
										<a class="pic" href="../video/watch-exclusive-cctv-footage-of-mansukh-hiren-1783480-2021-03-2567b2.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=watchrightnow&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=watchrightnow"><img alt="" class="lazyload" data-preview-url="" data-src="https://akm-img-a-in.tosshub.com/indiatoday/images/video/202103/ma_1_1200x768.jpeg?size=88:50" src="../../../akm-img-a-in.tosshub.com/sites/all/themes/itg/images/itg_image88x50.jpg" title=""/>
										<div class="playIconThumbContainer">
											<div class="platDetailVideoIcon"></div>
											<div class="platDetailVideoTime">
												07:09
											</div>
										</div></a>
										<p class="title" title="Watch: Exclusive CCTV footage of Mansukh Hiren"><a href="../video/watch-exclusive-cctv-footage-of-mansukh-hiren-1783480-2021-03-2567b2.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=watchrightnow&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=watchrightnow" title="Watch: Exclusive CCTV footage of Mansukh Hiren">Watch: Exclusive CCTV footage of Mansukh Hiren</a></p>
									</li>
									<li class="watch-right-now-list watch-right-now-1">
										<a class="pic" href="../video/devendra-fadnavis-led-bjp-delegation-meets-governor-bhagat-singh-koshyari-1782988-2021-03-2467b2.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=watchrightnow&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=watchrightnow"><img alt="" class="lazyload" data-preview-url="https://indiatoday-pdelivery.akamaized.net/indiatoday/video/2021_03/tooltips/24_mar_21_inside_scoop_on_meet_1024_512-preview.mp4" data-src="https://akm-img-a-in.tosshub.com/indiatoday/images/video/202103/Devendra_Fadpti_0_1200x768.jpeg?size=88:50" src="../../../akm-img-a-in.tosshub.com/sites/all/themes/itg/images/itg_image88x50.jpg" title=""/>
										<div class="playIconThumbContainer">
											<div class="platDetailVideoIcon"></div>
											<div class="platDetailVideoTime">
												04:14
											</div>
										</div></a>
										<p class="title" title="Devendra Fadnavis-led BJP delegation meets Governor Bhagat Singh Koshyari"><a href="../video/devendra-fadnavis-led-bjp-delegation-meets-governor-bhagat-singh-koshyari-1782988-2021-03-2467b2.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=watchrightnow&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=watchrightnow" title="Devendra Fadnavis-led BJP delegation meets Governor Bhagat Singh Koshyari">Devendra Fadnavis-led BJP delegation meets Governor Bhagat Singh Koshyari</a></p>
									</li>
									<li class="watch-right-now-list watch-right-now-2">
										<a class="pic" href="../video/sachin-vaze-used-fake-aadhaar-to-stay-at-5-star-hotel-in-mumbai-1782650-2021-03-2367b2.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=watchrightnow&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=watchrightnow"><img alt="" class="lazyload" data-preview-url="https://indiatoday-pdelivery.akamaized.net/indiatoday/video/2021_03/tooltips/23_mar_21_sachin_vaze_used_forged_id_to_book_hotel_room_nia_sources_1024_512-preview.mp4" data-src="https://akm-img-a-in.tosshub.com/indiatoday/images/video/202103/Screenshot_2021-03-23_at_14.38_0_1200x768.png?size=88:50" src="../../../akm-img-a-in.tosshub.com/sites/all/themes/itg/images/itg_image88x50.jpg" title=""/>
										<div class="playIconThumbContainer">
											<div class="platDetailVideoIcon"></div>
											<div class="platDetailVideoTime">
												02:09
											</div>
										</div></a>
										<p class="title" title="Sachin Vaze used fake Aadhaar to stay at 5-star hotel in Mumbai "><a href="../video/sachin-vaze-used-fake-aadhaar-to-stay-at-5-star-hotel-in-mumbai-1782650-2021-03-2367b2.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=watchrightnow&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=watchrightnow" title="Sachin Vaze used fake Aadhaar to stay at 5-star hotel in Mumbai ">Sachin Vaze used fake Aadhaar to stay at 5-star hotel in Mumbai</a></p>
									</li>
									<li class="watch-right-now-list watch-right-now-3">
										<a class="pic" href="../../elections/west-bengal-assembly-polls-2021/video/sunderbans-to-be-new-district-if-bjp-is-voted-to-power-says-amit-shah-at-bengal-rally-1782624-2021-03-2367b2.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=watchrightnow&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=watchrightnow"><img alt="" class="lazyload" data-preview-url="" data-src="https://akm-img-a-in.tosshub.com/indiatoday/images/video/202103/Screenshot_2021-03-23_at_13.38_0_1200x768.png?size=88:50" src="../../../akm-img-a-in.tosshub.com/sites/all/themes/itg/images/itg_image88x50.jpg" title=""/>
										<div class="playIconThumbContainer">
											<div class="platDetailVideoIcon"></div>
											<div class="platDetailVideoTime">
												17:19
											</div>
										</div></a>
										<p class="title" title="Sunderbans to be new district if BJP is voted to power, says Amit Shah at Bengal rally"><a href="../../elections/west-bengal-assembly-polls-2021/video/sunderbans-to-be-new-district-if-bjp-is-voted-to-power-says-amit-shah-at-bengal-rally-1782624-2021-03-2367b2.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=watchrightnow&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=watchrightnow" title="Sunderbans to be new district if BJP is voted to power, says Amit Shah at Bengal rally">Sunderbans to be new district if BJP is voted to power, says Amit Shah at Bengal rally</a></p>
									</li>
									<li class="watch-right-now-list watch-right-now-4">
										<a class="pic" href="../../coronavirus-outbreak/video/covid-surge-up-schools-upto-class-8-to-stay-shut-till-31-march-1782538-2021-03-2367b2.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=watchrightnow&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=watchrightnow"><img alt="" class="lazyload" data-preview-url="https://indiatoday-pdelivery.akamaized.net/indiatoday/video/2021_03/tooltips/23_mar_21_up_schools_shut_1024_512-preview.mp4" data-src="https://akm-img-a-in.tosshub.com/indiatoday/images/video/202103/Screenshot_2021-03-23_at_11.10_0_1200x768.png?size=88:50" src="../../../akm-img-a-in.tosshub.com/sites/all/themes/itg/images/itg_image88x50.jpg" title=""/>
										<div class="playIconThumbContainer">
											<div class="platDetailVideoIcon"></div>
											<div class="platDetailVideoTime">
												00:42
											</div>
										</div></a>
										<p class="title" title="Covid surge: UP schools upto class 8 to stay shut till 31 March"><a href="../../coronavirus-outbreak/video/covid-surge-up-schools-upto-class-8-to-stay-shut-till-31-march-1782538-2021-03-2367b2.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=watchrightnow&amp;t_source=rhs&amp;t_medium=It&amp;t_campaign=watchrightnow" title="Covid surge: UP schools upto class 8 to stay shut till 31 March">Covid surge: UP schools upto class 8 to stay shut till 31 March</a></p>
									</li>
								</ul>
							</div>
						</div>
						<div class="block block-itg-widget odd" id="block-itg-widget-top-takes-videos-widget">
							<div class="top-takes-video-container">
								<h3><span>Top Takes</span></h3>
								<ul>
									<li class="top-takes-video top-takes-list top-takes-0">
										<a class="pic" href="../../elections/video/watch-dindigul-leoni-s-sexist-remark-at-dmk-campaign-1783454-2021-03-25d79f.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=toptakes&amp;?t_source=rhs&amp;t_medium=It&amp;t_campaign=toptakes"><img alt="Watch: Dindigul Leoni's sexist remark at DMK campaign" class="lazyload" data-preview-url="https://indiatoday-pdelivery.akamaized.net/indiatoday/video/2021_03/tooltips/25_mar_21_dmks_sexist_leader_1024_512-preview.mp4" data-src="https://akm-img-a-in.tosshub.com/indiatoday/images/video/202103/le-88x50.jpeg?Db3SBDUZYuUYu4BJjXFgbQf_JAN5qlS_" src="../../../akm-img-a-in.tosshub.com/sites/all/themes/itg/images/itg_image88x50.jpg" title="Watch: Dindigul Leoni's sexist remark at DMK campaign"/>
										<div class="playIconThumbContainer">
											<div class="platDetailVideoIcon"></div>
											<div class="platDetailVideoTime">
												04:30
											</div>
										</div></a>
										<p class="title top-takes-1783454" title="Watch: Dindigul Leoni's sexist remark at DMK campaign"><a href="../../elections/video/watch-dindigul-leoni-s-sexist-remark-at-dmk-campaign-1783454-2021-03-25d79f.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=toptakes&amp;?t_source=rhs&amp;t_medium=It&amp;t_campaign=toptakes" title="Watch: Dindigul Leonis sexist remark at DMK campaign">Watch: Dindigul Leoni's sexist remark at DMK campaign</a></p>
									</li>
									<li class="top-takes-video top-takes-list top-takes-1">
										<a class="pic" href="../video/karnataka-congress-mlas-to-hold-all-night-protest-in-assembly-1782973-2021-03-24d79f.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=toptakes&amp;?t_source=rhs&amp;t_medium=It&amp;t_campaign=toptakes"><img alt="Karnataka Congress MLAs to hold all night protest in assembly" class="lazyload" data-preview-url="https://indiatoday-pdelivery.akamaized.net/indiatoday/video/2021_03/tooltips/24_mar_21_cong_demand_judicial_enquiry_into_jarkiholi_cd_1024_512-preview.mp4" data-src="https://akm-img-a-in.tosshub.com/indiatoday/images/video/202103/unnamedcghfghdghj_1200x768-88x50.jpeg?caNjl_IEHCxbPi_pEEg01ufbkMUlAkWU" src="../../../akm-img-a-in.tosshub.com/sites/all/themes/itg/images/itg_image88x50.jpg" title="Karnataka Congress MLAs to hold all night protest in assembly"/>
										<div class="playIconThumbContainer">
											<div class="platDetailVideoIcon"></div>
											<div class="platDetailVideoTime">
												01:15
											</div>
										</div></a>
										<p class="title top-takes-1782973" title="Karnataka Congress MLAs to hold all night protest in assembly"><a href="../video/karnataka-congress-mlas-to-hold-all-night-protest-in-assembly-1782973-2021-03-24d79f.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=toptakes&amp;?t_source=rhs&amp;t_medium=It&amp;t_campaign=toptakes" title="Karnataka Congress MLAs to hold all night protest in assembly">Karnataka Congress MLAs to hold all night protest in assembly</a></p>
									</li>
									<li class="top-takes-video top-takes-list top-takes-2">
										<a class="pic" href="../../programme/first-up/video/watch-heated-exchange-of-words-between-suvendu-adhikari-and-west-bengal-police-1782967-2021-03-24d79f.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=toptakes&amp;?t_source=rhs&amp;t_medium=It&amp;t_campaign=toptakes"><img alt="Watch: Heated exchange of words between Suvendu Adhikari and West Bengal Police" class="lazyload" data-preview-url="https://indiatoday-pdelivery.akamaized.net/indiatoday/video/2021_03/tooltips/24_mar_21_first_up_1024_512-preview.mp4" data-src="https://akm-img-a-in.tosshub.com/indiatoday/images/video/202103/Suvendu_Adhikari_nomination__P-88x50.jpeg?3TXwP9ZT8kcG9M51HfITDdwCyNuOOyON" src="../../../akm-img-a-in.tosshub.com/sites/all/themes/itg/images/itg_image88x50.jpg" title="Watch: Heated exchange of words between Suvendu Adhikari and West Bengal Police"/>
										<div class="playIconThumbContainer">
											<div class="platDetailVideoIcon"></div>
											<div class="platDetailVideoTime">
												21:26
											</div>
										</div></a>
										<p class="title top-takes-1782967" title="Watch: Heated exchange of words between Suvendu Adhikari and West Bengal Police"><a href="../../programme/first-up/video/watch-heated-exchange-of-words-between-suvendu-adhikari-and-west-bengal-police-1782967-2021-03-24d79f.html?utm_source=rhs&amp;utm_medium=It&amp;utm_campaign=toptakes&amp;?t_source=rhs&amp;t_medium=It&amp;t_campaign=toptakes" title="Watch: Heated exchange of words between Suvendu Adhikari and West Bengal Police">Watch: Heated exchange of words between Suvendu Adhikari and West Bengal Police</a></p>
									</li>
								</ul>
							</div>
						</div>
						<div class="block block-itg-ads last even" id="block-itg-ads-ads-medium-rectangl-rhs2-300x250">
							<div class='adtext'>
								advertisement
							</div>
							<div id='div-gpt-ad-1507709583969-2' style={{height:'250px', width:'300px' ,margin: 'auto'}}>
							
							</div>
						</div>
					</section>
				</aside>
			</div>
		</main>
	
	</div>

  
	<div id="snowplowid"></div>
    {/* <!-- Mirrored from www.indiatoday.in/india/story/crew-of-ever-green-ship-blocking-suez-canal-is-indian-1783659-2021-03-25 by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Mar 2021 14:36:05 GMT --> */}
</body>
    </>)
}

export default NewStory