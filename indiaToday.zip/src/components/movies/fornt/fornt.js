import React, { useEffect, useState } from "react";
import "./fornt.css";
export default function fornt() {
  return (
    <div className="most_main_div">
      <div className="main_div">
        <div className="heading_main_div">
          <div className="heading_div">
            <h1 className="heading">
              Deepika Padukone shares adorable childhood pic, calls herself
              Indiranagar ki gundi
            </h1>
          </div>
          <div className="pragraph_div">
            <h2 className="heading2">
              Deepika Padukone took to Instagram to share a baby picture of
              herself. She put a spin on Rahul Dravid's viral new advertisement
              and wrote ‘Indiranagar ki gundi hoon main’ in the caption.
            </h2>
          </div>
        </div>

        <div className="social_card_div">
          <div className="social_line_div"></div>
          <div className="social_pic_div"></div>
        </div>
        <div className="detail_div">
          <p className="p_div">
            Deepika Padukone will be next seen sharing screen space with Ranveer
            Singh in 83. The sports drama was slated to release in April 2020,
            however, it got pushed due to the novel coronavirus pandemic. The
            new release date of the film is June 4. The actress has wrapped up
            the shooting of Shakun Batra's yet-to-be-titled film with Siddhant
            Chaturvedi. Currently, Deepika is shooting for Shah Rukh
            Khan-starrer Pathan. The actress also has Fighter with Hrithik
            Roshan and an untitled project with Prabhas lined up. It was
            recently announced that Deepika Padukone and Amitabh Bachchan will
            reunite for the Indian adaptation of The Intern.
          </p>
        </div>

        <div className="post_card_div">
          <div className="cards_div">
            <div className="card_div">
              <div className="img_div">

                <div className="logo_div">
                <span class="thumbnail-overlay"></span>
                </div>
              </div>
              <div className="link_div">
              <span className="span_link " >Exams will be conducted as scheduled in Bengaluru</span>
              </div>
              <div className="foot_div">
              <span class="branding">India Today</span>
              </div>
            </div>
            <div className="card_div">
              <div className="img_div">

                <div className="logo_div">
                <span class="thumbnail-overlay"></span>
                </div>
              </div>
              <div className="link_div">
              <span className="span_link ">Exams will be conducted as scheduled in physical</span>
              </div>
              <div className="foot_div">
              <span class="branding">India Today</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="main2_div"></div>
    </div>
  );
}
