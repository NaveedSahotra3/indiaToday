import IndiaToday from './components/indiaToday'


function App() {
  return (
    <div className="App">
      <IndiaToday />
    </div>
  );
}

export default App;
